
package tallerpadel;
import tallerpadel.Modelo.PartidoPadel;
import tallerpadel.Persistencia.GestorBinario;
import tallerpadel.Persistencia.GestorTexto;
import java.util.List;
import java.util.ArrayList;
public class TallerPadel {

    public static void main(String[] args) {
        

        ArrayList<PartidoPadel> partidos =
                new ArrayList<>();

        PartidoPadel partido1 =
                new PartidoPadel(
                        "Pedro/Carlos",
                        "Josue/Santiago",
                        "6-3 7-5"
                );

        PartidoPadel partido2 =
                new PartidoPadel(
                        "Rosa/Maria",
                        "Martha/Blanca",
                        "6-7 6-1"
                );

        partidos.add(partido1);
        partidos.add(partido2);

        GestorBinario gestorBinario =
                new GestorBinario();

        GestorTexto gestorTexto =
                new GestorTexto();

        String archivoBinario =
                "partidos.dat";

        String archivoTexto =
                "partidos.txt";

        gestorBinario.guardarPartidos(
                partidos,
                archivoBinario
        );

        gestorTexto.guardarTexto(
                partidos,
                archivoTexto
        );

        ArrayList<PartidoPadel> datosBinarios =
                gestorBinario.cargarPartidos(
                        archivoBinario
                );

        ArrayList<PartidoPadel> datosTexto =
                gestorTexto.cargarTexto(
                        archivoTexto
                );

        System.out.println("\n===== DATOS DESDE .DAT =====");

        for (PartidoPadel partido : datosBinarios) {

            System.out.println(partido);
            System.out.println("--------------------");
        }

        System.out.println("\n===== DATOS DESDE .TXT =====");

        for (PartidoPadel partido : datosTexto) {

            System.out.println(partido);
            System.out.println("--------------------");
        }
    }
    
}
