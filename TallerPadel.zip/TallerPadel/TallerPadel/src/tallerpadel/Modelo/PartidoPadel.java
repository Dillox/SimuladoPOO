package tallerpadel.Modelo;

import java.io.Serializable;

public class PartidoPadel implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pareja1;
    private String pareja2;
    private String marcador;

    public PartidoPadel(String pareja1, String pareja2, String marcador) {
        this.pareja1 = pareja1;
        this.pareja2 = pareja2;
        this.marcador = marcador;
    }

    public String getPareja1() {
        return pareja1;
    }

    public void setPareja1(String pareja1) {
        this.pareja1 = pareja1;
    }

    public String getPareja2() {
        return pareja2;
    }

    public void setPareja2(String pareja2) {
        this.pareja2 = pareja2;
    }

    public String getMarcador() {
        return marcador;
    }

    public void setMarcador(String marcador) {
        this.marcador = marcador;
    }

    public String toString() {
        return "Pareja 1: " + pareja1 +
               "\nPareja 2: " + pareja2 +
               "\nMarcador: " + marcador;
    }
}