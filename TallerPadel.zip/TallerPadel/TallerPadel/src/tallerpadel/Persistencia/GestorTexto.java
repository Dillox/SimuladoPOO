package tallerpadel.Persistencia;
import tallerpadel.Modelo.PartidoPadel;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class GestorTexto {
      public void guardarTexto(ArrayList<PartidoPadel> partidos,
                             String archivo) {

        try (BufferedWriter bw =
                     new BufferedWriter(new FileWriter(archivo))) {

            for (PartidoPadel p : partidos) {

                bw.write(
                        p.getPareja1() + ";" +
                        p.getPareja2() + ";" +
                        p.getMarcador()
                );

                bw.newLine();
            }

            System.out.println("Datos guardados en texto.");

        } catch (IOException e) {

            System.out.println("Error: "
                    + e.getMessage());
        }
    }

    public ArrayList<PartidoPadel> cargarTexto(
            String archivo) {

        ArrayList<PartidoPadel> partidos =
                new ArrayList<>();

        try (BufferedReader br =
                     new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(";");

                PartidoPadel partido =
                        new PartidoPadel(
                                datos[0],
                                datos[1],
                                datos[2]
                        );

                partidos.add(partido);
            }

        } catch (IOException e) {

            System.out.println("Error: "
                    + e.getMessage());
        }

        return partidos;
    
    }
}