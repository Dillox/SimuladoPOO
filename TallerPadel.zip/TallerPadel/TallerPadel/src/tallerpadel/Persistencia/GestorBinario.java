
package tallerpadel.Persistencia;

import tallerpadel.Modelo.PartidoPadel;

import java.io.*;
import java.util.ArrayList;
public class GestorBinario {
     public void guardarPartidos(ArrayList<PartidoPadel> partidos,
                                String rutaArchivo) {

        try {

            FileOutputStream archivo =
                    new FileOutputStream(rutaArchivo);

            ObjectOutputStream escritor =
                    new ObjectOutputStream(archivo);

            escritor.writeObject(partidos);

            escritor.close();

            System.out.println("Partidos guardados correctamente en .dat");

        } catch (IOException e) {

            System.out.println("Error al guardar: "
                    + e.getMessage());
        }
    }

    public ArrayList<PartidoPadel> cargarPartidos(
            String rutaArchivo) {

        ArrayList<PartidoPadel> partidos =
                new ArrayList<>();

        try {

            FileInputStream archivo =
                    new FileInputStream(rutaArchivo);

            ObjectInputStream lector =
                    new ObjectInputStream(archivo);

            partidos =
                    (ArrayList<PartidoPadel>) lector.readObject();

            lector.close();

        } catch (IOException | ClassNotFoundException e) {

            System.out.println("Error al cargar: "
                    + e.getMessage());
        }

        return partidos;
    
    }
}